#!/bin/sh
echo harmless
